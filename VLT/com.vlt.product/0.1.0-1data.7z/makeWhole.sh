#!/bin/bash
cat $DIR/part* >> java-install.pkg
rm part*