/usr/bin/osascript << EOF
tell application "Finder"
set mySource to POSIX file "$1" as alias
make new alias to mySource at desktop
set name of result to "VLT"
end tell
EOF